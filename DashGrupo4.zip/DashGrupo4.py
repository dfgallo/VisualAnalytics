
import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import numpy as np
import plotly.express as px
import seaborn as sns

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

app = dash.Dash(__name__)


#importacion y manipulacion del dataset

df = pd.read_csv('RP_ARMAS.CSV', 
                 sep = ',',
                 thousands=',', decimal='.',
                 skip_blank_lines=True,
                 low_memory = False,
                 dtype={
                 })

a= ['DEPARTAMENTO', 'MUNICIPIO HECHO', 'CLASE BIEN', 'FECHA HECHO', 'CANTIDAD']
df_1 = df.copy()
df_1 = df_1[a]

df_query = df_1[['DEPARTAMENTO', 'MUNICIPIO HECHO', 'CLASE BIEN', 'FECHA HECHO', 'CANTIDAD']]

available_departamentos = df_1['DEPARTAMENTO'].unique()
available_clase_de_bien= df_1['CLASE BIEN'].unique()
available_Conteo = df_1['CANTIDAD'].unique()

# Visualizacion revolveres (Gallo)

df_revolver = df[(df['CLASE BIEN'] == "REVOLVER")]
tab_revolver=df_revolver['DEPARTAMENTO'].value_counts().rename_axis('Departamento').reset_index(name='Incautaciones')


fig_4= px.pie(tab_revolver, values='Incautaciones', names='Departamento', title='Revolveres incautados por departamento')

tab1 = pd.crosstab(df["DEPARTAMENTO"],df["CLASE BIEN"])
tab1

fig3 = px.imshow(tab1)
fig3.update_xaxes(side="top")
fig3.layout.height = 700
fig3.layout.width = 500
fig3.update_layout(
    xaxis_nticks=36)

#LAYOUT

app.layout = html.Div(
    children=[
        html.H1(children="REGISTRO DE INCAUTACIONES DE ARMAS POR LA POLICÍA NACIONAL",
            style = {
                        'textAlign': 'center',
            }),
        html.H2(children="2010--2021"),
        html.P(
            children="El conflicto armado ha sido una variable constante en la historia de Colombia, por casi 100 años el país se ha visto sumido en conflictos bélicos cuyos motivos han variado en el transcurso del tiempo, atravesando por conflictos políticos por el poder, narcotráfico y guerrillas armadas. "
            "Los datos recogidos sobre la incautación de armas de fuego por parte de la Policía Nacional desde el año 2010 permite *Descubrir* y *comparar* *tendencias* sobre la efectividad de la policía en estos procesos y la evolución de Colombia en el tratamiento del conflicto armado"
            ),
        html.Div([
        html.Div([
            html.H1(children='Gráfico 1 - Andres Perez'),#
            html.Div(children='''
             Grafico de sun burst, es un  grafico interactivo que presenta la cantidad de incautaciones por departamento y tipo de arma, este grafico permite hacer una comparacion mas directa entre departamentos y asi evitar comparaciones entre departamentos que probablemente tienen una discrepancia muy grande entre  incautaciones, asi mismo permite el analisis de un solo departamento, se recomienda usar el grafico maximo de a 3 departamentos seleccionados para no sobre cargar el grafico. 
            '''),#
            dcc.Checklist(id='crossfilter_departamentos1',
                options=[{'label': i, 'value': i} 
                            for i in available_departamentos],
                value = ['ANTIOQUIA','CLASE'],
                labelStyle={'display': 'inline-block'}
                ),
            dcc.Graph(
                id='example-graph-2'
            ),  
        ], className='six columns')
    ], className='row'),    


    html.H4(children='Armas incautadas por departamento'),

    html.Div([
        html.Div([
            html.H1(children='Gráfico 2 - Daniel Gallo'),#
            html.Div(children='''
                Este Treemap interactivo es una representación del tipo de armas incautadas por cada departamento, la interactividad de este gráfico permite desglosar y darle presición al tipo de armas que mas frecuentó incautaciones desde el 2010 hasta el 2021
            '''),#
            dcc.Dropdown(
                id='crossfilter_DEPARTAMENTO',
                options=[{'label': i, 'value': i} for i in available_departamentos],
                value = ['ANTIOQUIA'],
                multi = True 
            ),
            dcc.Graph(
                id='example-graph-1'
            ),  
        ], className='six columns'),
        ], className='row'),   
    html.H4(children='Cantidad de incautaciones por tipo de arma y departamento'),
     html.Div([
        html.Div([

            html.H1(children="Grafico 2 - Andres Perez"),
            html.Div(
                children="En ésta visualización se puede observar una perspectiva mas directa de las incautaciones y sus comparaciones directas, este grafico permite evidenciar particularidades como el uso de pistolas revoleveres   y escopetas, es muy global independiente del departamento, tambien muestra en que departamentos se generan mas estas incautaciones"

                ),
          dcc.Graph(
            id='example-graph-3',
            figure=fig3
            ),
        ], className='six columns'),
        ], className='row'),
      
    html.H4(children='Revolveres incautadas por departamento'),
     html.Div([
        html.Div([

            html.H1(children="Grafico 2 - Daniel Gallo"),
            html.Div(
                children="En ésta visualización se puede observar "
                "la distribución de la incautación de revólveres "
                "a lo largo de cada departamento colombiano,"
                "teniendo en cuenta que los revólveres son el tipo de arma con mayor cantidad de incautaciones"
                "a lo largo del país."
                ),
          dcc.Graph(
            id='example-graph-4',
            figure=fig_4
            ),
        ], className='six columns'),
        ], className='row'),
      
])
## Andres1

@app.callback(
    dash.dependencies.Output('example-graph-2', 'figure'),
    [dash.dependencies.Input('crossfilter_departamentos1', 'value')]
    )

def update_graph(cantidad_armas_value):

    query1 = df_1[df_1['DEPARTAMENTO'].isin(cantidad_armas_value)]
    query1 = pd.pivot_table(query1, 
                        values='CANTIDAD', 
                        index=['DEPARTAMENTO','CLASE BIEN'],
                        aggfunc=np.sum)
    query1 = query1.reset_index().rename_axis(None, axis=1)
    query1 = query1.sort_values(by=['CANTIDAD'],ascending=False)

    fig2 = px.sunburst(query1, path=['DEPARTAMENTO','CLASE BIEN'], values='CANTIDAD')

    return fig2

#Gallo1
@app.callback(
    dash.dependencies.Output('example-graph-1', 'figure'),
    [dash.dependencies.Input('crossfilter_DEPARTAMENTO', 'value')]
    )

def update_graph(DEPARTAMENTO_value):

    query2 = df_1[df_1['DEPARTAMENTO'].isin(DEPARTAMENTO_value)]
    query2 = query2.reset_index().rename_axis(None, axis=1)


  
    fig1 = px.treemap(query2, path=['DEPARTAMENTO', 'CLASE BIEN'], color='DEPARTAMENTO')

    return fig1


if __name__ == "__main__":
    app.run_server(debug=True)
